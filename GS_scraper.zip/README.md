# GuruShots scraper

## Instalace

    yarn install

## Spuštění

    yarn start

## Použití

Pro generování aktuálních týmových soutěží.

<http://localhost:3000/team-challenges?user={EMAIL}&pwd={PASSWORD}>
